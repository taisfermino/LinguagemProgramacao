
package br.com.bandtec.lista2;

import java.util.Scanner;


public class Exercicio4 {
     public static void main(String[] args) {
        
        for(Integer n=0; n <= 90; n++){
            if(n % 2 != 0){
                System.out.println(n);
            }
     }
}
}